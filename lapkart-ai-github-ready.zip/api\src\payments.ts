import crypto from "node:crypto";
import Razorpay from "razorpay";
import { config } from "./config.js";

export const razorpay =
  config.razorpayKeyId && config.razorpayKeySecret
    ? new Razorpay({ key_id: config.razorpayKeyId, key_secret: config.razorpayKeySecret })
    : null;

export async function createRazorpayOrder(amountPaise: number, receipt: string) {
  if (!razorpay) {
    return { id: `order_mock_${Date.now()}`, amount: amountPaise, currency: "INR", receipt, status: "created" };
  }

  return razorpay.orders.create({
    amount: amountPaise,
    currency: "INR",
    receipt,
    payment_capture: true,
  });
}

export function verifyRazorpaySignature(input: {
  orderId: string;
  paymentId: string;
  signature: string;
}) {
  if (!config.razorpayKeySecret) return input.signature.startsWith("mock_");
  const body = `${input.orderId}|${input.paymentId}`;
  const expected = crypto.createHmac("sha256", config.razorpayKeySecret).update(body).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(input.signature));
}
